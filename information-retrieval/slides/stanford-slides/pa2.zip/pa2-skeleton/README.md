## CS276 PA2

### Quick Start
Run the following commands from the root directory of the assignment:
  1. `conda env create -f environment.yml`
  2. `conda activate cs276-pa2` (or `source activate cs276-pa2`)
  3. `jupyter notebook`

This will launch a Jupyter Notebook session in your web browser,
where you can finish the assignment by filling out `pa2-skeleton.ipynb`.
All further instructions can be found in the Jupyter Notebook.
